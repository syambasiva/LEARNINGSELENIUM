//
package A;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BHandlingCalendersUI {
public static void main(String[] args) {
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.path2usa.com/travel-companions");
	
	driver.findElement(By.id("travel_date")).click();
	
	    
	
	while( !driver.findElement(By.xpath("//div[@class='datepicker-days']//th[@class='datepicker-switch']")).getText().contains("February"))
	{
		driver.findElement(By.xpath("//div[@class='datepicker-days']//th[@class='next']")).click();
	}
	 
	 
	 
	 //div[@class='datepicker-days']//th[@class='datepicker-switch']
    //div[@class='datepicker-days']//th[@class='next']
	
	
	
	
	
	    List<WebElement> dates = driver.findElements(By.xpath("//div[@class='datepicker-days']//td[@class='day']"));
	    int count = driver.findElements(By.xpath("//div[@class='datepicker-days']//td[@class='day']")).size();
	    for(int i=0;i<count;i++)
	    {
	    	
	    	String text = driver.findElements(By.xpath("//div[@class='datepicker-days']//td[@class='day']")).get(i).getText();
	    	if(text.equalsIgnoreCase("23"))
	    	{
	    		 driver.findElements(By.xpath("//div[@class='datepicker-days']//td[@class='day']")).get(i).click();
	    		 break;
	    		
	    	}
	    	
	    	
	    }
}

}
