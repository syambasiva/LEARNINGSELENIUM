/*
 1.give me the links of webpage
 2.give the links count of footer
 */
package A;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class APrintLinksCountInThePage {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("http://qaclickacademy.com/practice.php");

		System.out.println(driver.findElements(By.tagName("a")).size());

		WebElement footerdriver = driver.findElement(By.id("gf-BIG"));//limiting scope of WebDriver
		System.out.println(footerdriver.findElements(By.tagName("a")).size());
		
		
		WebElement coloumndriver = footerdriver.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
		System.out.println(coloumndriver.findElements(By.tagName("a")).size());
		
		
		for(int i=0;i<coloumndriver.findElements(By.tagName("a")).size();i++)
		{
			
			 String ClickOnLinkTab =Keys.chord(Keys.CONTROL,Keys.ENTER);
			  
			 coloumndriver.findElements(By.tagName("a")).get(i).sendKeys(ClickOnLinkTab);
			 Thread.sleep(5000);
			
		}
			  Set<String> ids =driver.getWindowHandles();
	        
			  Iterator<String> it = ids.iterator();
			  
			  
			  while(it.hasNext())
			  {
				
				  driver.switchTo().window(it.next());
				  System.out.println(driver.getTitle());
			  }
			  
			
		}
		
		

	}


