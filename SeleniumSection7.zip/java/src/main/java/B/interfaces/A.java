/*
 Introduction: interface will have method without body The classes which takes an agreement to implement those interface tose implements 
 those methods.
 
 2.*by default interface methods are public so in child while implementing declare with public 
 */

package B.interfaces;

public class A {

}
