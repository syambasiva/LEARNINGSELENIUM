package ATest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class B {
	
	
	@Test
	public void DemoClassB()
	{
		System.out.println("TestNgTutorial");
	}
	@BeforeTest
	public void DemoClass()
	{
		System.out.println("I will execute First");
	}
   


}
