package ATest;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class C {

	@BeforeClass
	public void BeforeClass()
	{
		System.out.println("I will execute before the class");
	}
	
	@Parameters({ "URL" })
	@Test
	public void WebloginCarLoan(String urlName)
	{
		System.out.println("WebloginCarLoan");
		System.out.println(urlName);
	}
	
	@Test(groups= {"Smoke"})
	public void MobileloginCarLoan()
	{
		System.out.println("MobileloginCarLoan");
	}
	@Test
	public void MobilesigninCarLoan()
	{
		System.out.println("MobilesigninCarLoan");
	}
	@Test
	public void MobilesignoutCarLoan()
	{
		System.out.println("MobilesignoutCarLoan");
	}
	
	@Test
	public void LoginAPIloginCarLoan()
	{
		System.out.println("LoginAPIloginCarLoan");
	}
	@AfterClass
	public void AfterClass1()
	{
		System.out.println("I will execute After class");
	}
	
}
