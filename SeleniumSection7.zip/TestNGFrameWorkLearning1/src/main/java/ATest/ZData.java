package ATest;

public class ZData {

}
/*
  Assignment:Section8
  www.cleartrip.com
  
  select Adult
  current date dept on
  click on more options link
  one way or round trip.
  
  
 */
/*

A.How to run tests with TestNG?

    you need to have @Test Annotation followed by method.
     
    you can define multiple test from single class.
    
    you can modularize TestCase based on Functionality Accordingly.
    
    
    
    you can also get a control on running specific methods from test Case.
     
     Annotations:
     @Test
     @suit-for defining global 
    
 Groups:
            client requirement is to run 40 out of 100 can use in sucn cases also A.groups
   
Helper Attributes:
                 * 1.Enable:
                      * = false
                     * when interview ask i know that there are some errors that i want should not trigger
      
                      2. DependOn:
                       3.timeOut:
     
Parameterization:
                    Applying on suit level XML-4
                    test level Xml-5
  
DataProviders:
    
    multiple data
    set of data want to run that test case for multiple data sets if we have 20 data sets if we want to run test data 20 times with 
    20 different data 
   
   
TestNgListners:
Parllel Running Tests and Generating Result:
can achieve by using thread-count and parllel = tests
can do parllel operation class Level also

*/

/*-------------------------------------------------------------------------------------------------------------------------------
 * framework-2
 * properties file - how to retrive data from propertises file.
 * base class explination.
 *-----------------------------------------------------------------------------------------------------------------------------/


/*
 * Framework-3 Maveen
 * it is a build management tool
 * 1.central repository to get dependencies:
 *         
 *         
 * 2.Maintining common Structure across Organisation:
 * 
 *         In a company there are multiple teams working on multiple  frameworks.
 *         each team defines there own structures with different packages and folders for Test data.
 *         there is no consistency in maintainig the Skeleton.
 *         
 *          To maintain one common Framework structure across the organisatin we can use maveen: 
 *          
 *          1.Maveen automatically suggest some templates.
 *          for developing(2.1.Maveeen in 5min GOthrough) 
 *              
 *      
 * 3.Flexibility in integrating with CI tools:
 *           
 *           To execute all the test cases automatically without manual intervension we need to integrate to jenkins.
 *           To Make your project compatable with jenkins we need to adapt one build management tool for your framework.
 *            Here we  to we have used build management tool i.e Maveen	
 *
 * 4.Plugins for Test FrameWork execution:
 *             maveen will support TestNG,Junit
 * 
 *  NOTE:Keeping these these SMT Or build management Tool for developing framework and  CI  POM.xml is the heart of Maveen    
 *  
 *       Maveen surefire Plugin: will help to execute all test cases in the  maveen project
 *       
 *       doubt :1.clean in maveeen 2.compile 3.test
 *
 * 5.Integrating TestNG with Maveen      
 * 
 * 6.switching the Tests with Maveen Profiling
 *  
 *        need to know regression and smoke and how it in real time
 *        
 *        by using profiles we can achieve it 
 *        
 *        profiles is the Parent under profiles you can mention many child profile like regression and smoke with XMl file related
 *       
 *        
 *        
 *        
 *        FrameWork:4
 *        java -jar jenkins.war -httpPort=9090
 *        usn:syambasiva
 *        psw:Sambasiva@51
 *        email:Sambarebel50@gmail.com
 *        
 *        click:managegenkins
 *        global tool configuration, link your java and maveen and save
 *        
 *        create new job where you can give the git path where excatly your code is
 *        
 *        after creating click on bulid Now 
 *        
 *        after click on console output can view all outputs.
 *        
 *        
 *        
 *        
 */





