package ATest;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class D {


	@BeforeMethod
	public void BeforeMethod()
	{
		System.out.println("I will execute after each Method ");
	}
	@Test
	public void WebloginHomeLoan()
	{
		System.out.println("WebloginHomeLoan");
	}
	@Parameters({ "URL" })
	@Test
	public void MobileloginHomeLoan(String urlName)
	{
		System.out.println("MobileloginHomeLoan");
		System.out.println(urlName);
	}
	
	@Test(groups= {"Smoke"})
	public void LoginAPIloginHomeLoan()
	{
		System.out.println("LoginAPIloginHomeLoan");
	}
	
	@AfterMethod
	public void AfterMethod()
	{
		System.out.println("I will execute after each Method ");
	}
	@BeforeSuite
	public void BeforeSuit()
	{
		System.out.println("I will execute No 1 from top");
	}
}
