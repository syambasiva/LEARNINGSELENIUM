//hasnext  for checking whether next cell or row or column to move
//next move on to next cell or row or column
package com.test.automation.excelReader;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class B {

	public static void main(String[] args) throws IOException {

		
		
		
		FileInputStream fis = new FileInputStream("C:\\Users\\syambasiva.kuraba\\Desktop\\TestData.xlsx");
		
		//Navigating to the path of Excel by using WorkBook
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		//Storing the count of  sheets in the workbook and storing in a variable
		int sheets = workbook.getNumberOfSheets();
		

		//iterating by using loop Untill getting the desired sheet
		for (int i = 0; i < sheets; i++) {

			if (workbook.getSheetName(i).equalsIgnoreCase("TestData1")) {

				XSSFSheet sheet = workbook.getSheetAt(i);
				
				//Identify TestCase column by scanning the entire 1strow

				Iterator<Row> rows = sheet.iterator();// sheet is a collection of rows

				Row firstrow = rows.next();// moving to first row of the sheet

				Iterator<Cell> ce = firstrow.cellIterator();// row is collection of cells and all the cells data in a
															// first is stored in ce

				int k = 0;
				int columName = 0;
				while (ce.hasNext()) {
					Cell value = ce.next();
					if (value.getStringCellValue().equalsIgnoreCase("TestCases")) {

						columName = k;

					}
					k++;

				}
				System.out.println(columName);

				// once column is identified then scan entire testCase column to identify
				// purchase testCaserow

				while (rows.hasNext()) {

					Row r = rows.next();
					if (r.getCell(columName).getStringCellValue().equalsIgnoreCase("purchase")) {

						//after you grab purchase TestCase row pull all the data of that row  and feed 	into test
						Iterator<Cell> cv = r.cellIterator();

						while (cv.hasNext()) {
							System.out.println(cv.next().getStringCellValue());

						}

					}

				}

			}
		}

	}
}
