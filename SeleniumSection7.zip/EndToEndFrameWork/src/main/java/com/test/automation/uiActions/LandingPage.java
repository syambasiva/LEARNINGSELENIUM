package com.test.automation.uiActions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {

	public WebDriver driver;

	By signin = By.xpath("//span[text()='Login']");
	By title = By.xpath("//div[@class='text-center']/h2[text()='Featured Courses']");
	By popup = By.xpath("//button[text()='NO THANKS']");
	
	By NavBar =By.xpath("");

	public LandingPage(WebDriver driver) {

		this.driver = driver;
	}

	public WebElement getLogin() {
		return driver.findElement(signin);
	}
	
	public WebElement getTitle() {
		return driver.findElement(title);
	}
	public int getPopupSize() {
		return driver.findElements(popup).size();
	}
	
	public WebElement getPopup(){
		return driver.findElement(popup);
	}

}
