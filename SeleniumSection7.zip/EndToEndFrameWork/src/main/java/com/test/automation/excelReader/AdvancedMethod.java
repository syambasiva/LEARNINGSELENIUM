package com.test.automation.excelReader;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class AdvancedMethod {

	public Map<String, String> excelReader(String moduleName, String sheetname) throws Exception {

		 

        String excelpath = System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\InmarsatTestData.xlsx";
        String filePath = excelpath;
        String expectedDataTCName = moduleName;

 

        File srcsan = new File(filePath);
        FileInputStream fisan = new FileInputStream(srcsan);
        XSSFWorkbook wbsan = new XSSFWorkbook(fisan);
        XSSFSheet sheetsan1 = wbsan.getSheet(sheetname); // get the data based on sheet name
        // XSSFSheet sheetsan1 = wbsan.getSheetAt(0); //index no can also be used

 

        int totalRow = sheetsan1.getLastRowNum() + 1;
        int totalColumn = sheetsan1.getRow(0).getLastCellNum();

 

        String[][] arr = new String[totalColumn][2];

 

        if (totalRow != 0) {

 

            for (int j = 0; j < totalColumn; j++) {
                String cellVal = sheetsan1.getRow(0).getCell(j).getStringCellValue();
                arr[j][0] = cellVal;
            }
        } else {
            log("In Testdata.xls - Rows not found");
        }

 

        for (int i = 0; i < totalRow; i++) {
            String value = sheetsan1.getRow(i).getCell(0).getStringCellValue();
            if (value.equals(expectedDataTCName)) {
                for (int j = 0; j < totalColumn; j++) {
                    String cellVal = sheetsan1.getRow(i).getCell(j).getStringCellValue();
                    arr[j][1] = cellVal;
                }
            }
        }

 

        HashMap<String, String> testDataValue = new HashMap<String, String>();
        for (int i = 0; i <= totalColumn - 1; i++) {
            testDataValue.put(arr[i][0], arr[i][1]);
        }

 

        wbsan.close();
        return testDataValue;

 

    }

	private void log(String string) {
		// TODO Auto-generated method stub
		
	}

	
}
