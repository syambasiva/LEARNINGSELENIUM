package com.test.automation.uiActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PoratalHomePage {
	

public WebDriver driver;
	
  By searchBox = By.name("query");

	
	public PoratalHomePage(WebDriver driver) {
		
		this.driver = driver;
	}
	
	
	public WebElement getSearchBox()
	{
		return driver.findElement(searchBox);
	}
	
	
	
}
