package TestExecutionDriver;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.test.automation.TestBase.base;
import com.test.automation.uiActions.LandingPage;




public class ValidateTitle extends base {
	
	private static Logger log = LogManager.getLogger(base.class.getName());
	
	@BeforeTest
	public void initialize() throws Exception
	{
		 init(); 	
	log.info("Driver is inatialised");	 
	}
	@Test
	public void basePageNavigation() throws InterruptedException
	{
		
		 LandingPage l = new LandingPage(driver);
		 Assert.assertEquals(l.getTitle().getText(), "FEATURED COURSES");
		 log.info("title is sucessfully validated");
		
	}
	
@AfterTest
public void TearDown()
{
	driver.close();
	driver=null;
}
	
	
}
