package TestExecutionDriver;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.automation.TestBase.base;
import com.test.automation.uiActions.LandingPage;
import com.test.automation.uiActions.LoginPage;



public class HomePage extends base {
	
	private static Logger log = LogManager.getLogger(base.class.getName());
	
	@BeforeTest
	public void initialize() throws Exception
	{
		 init();
		 log.info("driver is initilised for homePage");
	}
	
	
	@Test(dataProvider="getData")
	public void basePageNavigation(String Username,String Password,String text) throws Exception
	{
		
		 LandingPage l = new LandingPage(driver);
		 l.getLogin().click();
		 log.info("clicked on login sucessfully");
		 LoginPage Login = new LoginPage(driver);
		 Login.Email().sendKeys(Username);
		 Login.Password().sendKeys(Password);
		 System.out.println(text);
		 Login.LoginButton().click();
	}
	
	
	@DataProvider
	public Object[][] getData()
	{
		Object[][] data = new Object[2][3];
		
		data[0][0] = "nonrestricteduser@QA.com";
		data[0][1] = "1234567";
		data[0][2] = "Samba";
		
		data[1][0] = "restricteduser@QA.com";
		data[1][1] = "1234567";
		data[1][2] = "Siva";
		
		return data;
	}
	
	
	@AfterTest
	public void TearDown()
	{
		driver.close();
		driver=null;
	}
}
	

