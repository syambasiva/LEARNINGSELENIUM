package stepDefinitions;

import org.testng.Assert;

import com.test.automation.TestBase.base;
import com.test.automation.uiActions.LandingPage;
import com.test.automation.uiActions.LoginPage;
import com.test.automation.uiActions.PoratalHomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDefinition extends base{


@Given("^Initialise the browser$")
public void initialise_the_browser() throws Throwable {
   
	 init();
}

@Given("^Navigate to \"([^\"]*)\" site$")
public void navigate_to_site(String arg1) throws Throwable {
	driver.get(arg1);    
    
}

@Given("^Click on Login link in homePage to land on secure sign in Link$")
public void click_on_Login_link_in_homePage_to_land_on_secure_sign_in_Link() throws Throwable {
	 LandingPage l = new LandingPage(driver);
	 if(l.getPopupSize()>0)
	 {
		 l.getPopup().click();
	 }
	 l.getLogin().click();
   
}


@When("^user enters (.+) and (.+) and logs in$")
public void user_enters_and_and_logs_in(String username, String password) throws Throwable {
	 LoginPage Login = new LoginPage(driver);
	 Login.Email().sendKeys(username);
	 Login.Password().sendKeys(password);
	 Login.LoginButton().click();
}



@Then("^Verify that user is sucessfully logged in$")
public void verify_that_user_is_sucessfully_logged_in() throws Throwable {
	
   PoratalHomePage p = new PoratalHomePage(driver);
   Assert.assertTrue(p.getSearchBox().isDisplayed());
   
} 

@Then("^close browsers$")
public void close_browsers() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    driver.quit();
}

}
