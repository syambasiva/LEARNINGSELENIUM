/*
 There is another explicit wait mechanism type called Fluent Wait.
 
 Explicit wait can be achieved in 2 ways.
 1.WebDriver Wait 
 2.Fluent Wait
 difference between WebDriver Wait and Fluent Wait:
  
  WebDriver continuously monitor DOM for every millisecond. 
 
 fluentWait:
 finds the web element repeatedly at regular intervals of time until the timeout or till the object gets found.
 
 
 both WebDriver and fluentWait are two clases which are implementing Wait interface
 */
package ASynchronisationUsageinSelenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CFluentWait {
	
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	}

}
