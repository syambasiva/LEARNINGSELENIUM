/*
 types of synchronisation in selenium
 
 1.implict
 2.explict
 3.thread.sleeo
 4.fluentWait
 
 difference b/w implict and Explict wait?
 
 implict wait:
 global declaring the wait so it is called implict wait.
 
 advantages: defining globaly b/w each and every page it takes some time it is applicable to entire testcase untill webdriver kills.
 
 disadvantages:makes some performance issue if it is taking 5 sec it will wait at each and every action and hence reduce performance
 
 Explict:
 here we can target a specific Element
 applicable to specific element only
 
 interview Question:
 what was the ideal strategy of using synchronisation in selenium webdriver?
 Ans:implict and Explict and combination of both is an ideal solution.
 
 
 Thread.sleep: holding the execution for some time( java test for some time by using Thread.sleep).Because it is not a part of selenium webdriver but part of java.
 
 fluentWait:
  
 */
package ASynchronisationUsageinSelenium;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AImplictWait {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		String[] itemNames = { "Brocolli", "Cauliflower", "Cucumber" };

		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		Thread.sleep(300);
		addItems(driver, itemNames);
		driver.findElement(By.cssSelector("img[alt='Cart']")).click();
		driver.findElement(By.xpath("//button[contains(text(),'PROCEED TO CHECKOUT')]")).click();
		driver.findElement(By.xpath("//input[@class='promoCode']")).sendKeys("rahulshettyacademy");;
		driver.findElement(By.cssSelector("button.promoBtn")).click();
		System.out.println(driver.findElement(By.cssSelector("span.promoInfo")).getText());

	}

	private static void addItems(WebDriver driver, String[] itemNames) {
		// TODO Auto-generated method stub

		int j = 0;
		List<WebElement> products = driver.findElements(By.cssSelector("h4.product-name"));

		for (int i = 0; i < products.size(); i++) {

			String[] productName = products.get(i).getText().split("-");

			String FormattedName = productName[0].trim();

			List ItemsNeededList = Arrays.asList(itemNames);

			if (ItemsNeededList.contains(FormattedName)) {
				j++;
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();

				if (j == itemNames.length) {
					break;
				}

			}

		}

	}

}
