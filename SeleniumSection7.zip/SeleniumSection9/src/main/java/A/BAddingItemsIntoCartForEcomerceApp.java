package A;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BAddingItemsIntoCartForEcomerceApp {

	public static void main(String[] args) {
		
		

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		int j=0;
		String[] itemNames = {"Brocolli","Cauliflower","Cucumber"};//Storing the Names of items in String Array 
		//storing by using Array Not by using ArrayList First Why?
		//because Array takes less memory compare to ArrayList so that is the reason
		
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		List<WebElement> products = driver.findElements(By.cssSelector("h4.product-name"));
		
	
		
		
		
		for (int i = 0; i < products.size(); i++) {
			
			String[] productName = products.get(i).getText().split("-");//to achieve static value only and remove dynamic thing 
			//we are storing in Array format by using split
			String FormattedName = productName[0].trim();//trims the white spaces both at left and right most               
			
			
			 List ItemsNeededList = Arrays.asList(itemNames);//converting Array to Array List
			 
			//it will be applicable for only one item if we need multiple items
			if(ItemsNeededList.contains(FormattedName))
			{
				j++;
				driver.findElements(By.xpath("//button[text()='ADD TO CART']")).get(i).click();
				//break;//for single item selecting from cart we need to use break to reduse unwanted iterations
				
				if(j==3)
				{
					break;
				}
				
			}

		}
	
		
		
	}
	


}
