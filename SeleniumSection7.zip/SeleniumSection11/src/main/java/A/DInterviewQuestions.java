/*


1.mouse over can be done by using Actions class.

2.how do you handle multiple windows?

switch to window(driver.switchTo().window(childId);) pass the parameter of id of that window

driver.windowhandles is a method that gives all the windows and there ids throw them into iterator and traverse to window  

3.frames:

*/