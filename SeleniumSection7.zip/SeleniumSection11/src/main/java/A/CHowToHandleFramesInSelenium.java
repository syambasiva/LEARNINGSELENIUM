package A;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CHowToHandleFramesInSelenium {
	
	public static void main(String[] args) {
		
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://jqueryui.com/droppable/");
	
	    //1.switching to frame by using index
	    System.out.println(driver.findElements(By.tagName("iframe")).size());
	     driver.switchTo().frame(0);
	    
	//2.switching to frame by using webElement
	     
	//driver.switchTo().frame(driver.findElement(By.cssSelector("iframe.demo-frame")));//by using Webelement
	//driver.findElement(By.id("draggable")).click();
	Actions a = new Actions(driver);
	WebElement source = driver.findElement(By.id("draggable"));
	WebElement target = driver.findElement(By.id("droppable"));
	a.dragAndDrop(source, target).build().perform();
	
	//moves back to normal page i.e out of frame
	driver.switchTo().defaultContent();
	
	}
}
