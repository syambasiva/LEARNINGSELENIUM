package A;

public class MInterviewQuestions {
	
	

}
/*
1.how to handle Dropdowns?
AnS:By using select class there is a class called select in webDriver to handle dropDowns  

different methods:

by using text
by using index
by using value

can multiple options from dropDown and Deselect Multiple Options.

2.how do you handle java Alerts?

ANS:by using SwitchTo Alert then the operation
Alert is the method that we need to switch
Accept is a method that we need to click on Ok on that popUp
Dismiss is the method that we need to click cancel on that popUp
getText is the method if we need to get text on Alert

3.How to handle checkboxes?

ANS:isSelected Method to know whether checkbox is selected or not
After that 
IsDisabled and IsEnabled whether the button is enable or not

4.how do you hadle radioButton?

Q.i need to select radio button having same attribute by using FindElements and traverse into list and select then



*/