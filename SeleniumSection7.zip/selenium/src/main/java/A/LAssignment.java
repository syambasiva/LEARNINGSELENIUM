package A;

public class LAssignment {

}
