import java.io.IOException;
import java.util.ArrayList;

import A.CDatadriven;
import A.D;

public class CTestSample {
	
	public static void main(String[] args) throws IOException {
		
		
		
	   D d = new  D();
	   
	   ArrayList data = d.getData("TestData1","TestCases","Add Profile");
	   
	   
	   System.out.println(data.get(0));
	   System.out.println(data.get(1));
	   System.out.println(data.get(2));
	   System.out.println(data.get(3));
		
	}

}
