/*
 
Strategy to Access Excel Data 
 
 XSSFWorkBook: first create a object and pass the path of worksheet

 Sheet is collection of rows and coloums to get rows we are using iterator
 once row is selected again using iterator to traverse to cells in a row
 
*/
package A;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class A {

	public static void main(String[] args) throws IOException {

		FileInputStream fis = new FileInputStream("C:\\Users\\syambasiva.kuraba\\Desktop\\TestData.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		int sheets = workbook.getNumberOfSheets();

		for (int i = 0; i < sheets; i++) {

			if (workbook.getSheetName(i).equalsIgnoreCase("TestData1")) {

				XSSFSheet sheet = workbook.getSheetAt(i);

				Iterator<Row> rows = sheet.iterator();// sheet is a collection of rows

				Row firstrow = rows.next();// moving to first row of the sheet

				Iterator<Cell> ce = firstrow.cellIterator();// row is collection of cells and all the cells data in a
															// first is stored in ce

				int k = 0;
				int columName = 0;
				while (ce.hasNext()) {
					Cell value = ce.next();
					if (value.getStringCellValue().equalsIgnoreCase("TestCases")) {

						columName = k;

					}
					k++;

				}
				System.out.println(columName);

			}
		}

	}
}
