/*
 Link:   https://logging.apache.org/log4j/2.x/
 
 LogManager is a API and getLogger is a method inside it
 
 
 <?xml version="1.0" encoding="UTF-8"?>
<Configuration status="WARN">

//ApprndersTag:Appender Tag consists of two Tags
 //1.console:            console(inside the console Tag we are mentioning where to Log)
 //2.PatternLayout:      PatternLayout(inside the pattern tag in what formate the log4j looks is mentioned)
  
  <Appenders>
             <Console name="Console" target="SYSTEM_OUT">
               <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
             </Console>
 </Appenders>
  
  
  <Loggers>
         <Logger name="com.foo.Bar" level="trace">
                 <AppenderRef ref="Console"/>
                    </Logger>
    <Root level="error">
         <AppenderRef ref="Console"/>
    </Root>
  
 </Loggers>
</Configuration>
 
 Where to Log?
 
 Appenders Tag_console(inside the console Tag we are mentioning where to Log)
 
 what to Log?
 
 LoggersTag (if we need only error or mention Level is error and if we need entire mention level is trace)
 
 how to Log?
  Appenders Tag_PatternLayout(inside the pattern tag in what formate the log4j looks is mentioned) 
 
 */
package BLog4j;

import org.apache.logging.log4j.*;

public class A {

	private static Logger log = LogManager.getLogger(A.class.getName());

	public static void main(String[] args) {

		log.debug("I am debugging");
		log.info("object is present");
		log.error("object is not present");
		log.fatal("this is fatal");

	}
}
