package BLog4j;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class B {
	private static Logger log = LogManager.getLogger(B.class.getName());
	
	public static void main(String[] args) {
		
		log.debug("Samba is debugging");
		log.info("information is giving while initialising");
		log.error("error occur on failure");
		log.fatal("this is fatal");
		
		
	}

}
