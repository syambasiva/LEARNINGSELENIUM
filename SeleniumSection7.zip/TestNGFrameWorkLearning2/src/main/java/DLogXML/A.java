//Interview Questions:
//how to send entire logs of file
//how to get Logs only when there is error for packageA
//how to get log the entire message for packageB
//how to get logs with time stamp
//how if i want the log file of last week.
//how will i know if there is any error by just looking at logs?

/*
 1==basic Log4j Xml:
 
 1.if we change the trace is error only error logs will be captured
 2.if it is trace then all logs will be captured
--------------------------------------------------------------------------------------------------------------------------------------

<?xml version="1.0" encoding="UTF-8"?>
<Configuration status="WARN">
  <Appenders>
    <Console name="Console" target="SYSTEM_OUT">
      <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
    </Console>
  </Appenders>
  <Loggers>
    <Root level="trace">
      <AppenderRef ref="Console"/>
    </Root>
  </Loggers>
</Configuration>
_____________________________________________________________________________________________________________________________________

2==package level differentiating package level and generating logs
specifing the name of the packag and class what type of logs to be needed for specified one 

-------------------------------------------------------------------------------------------------------------------------------------
 <?xml version="1.0" encoding="UTF-8"?>
<Configuration status="WARN">
  <Appenders>
    <Console name="Console" target="SYSTEM_OUT">
      <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
    </Console>
  </Appenders>
  <Loggers>
  
  <Logger name="BLog4j.A" level="error" additivity="false">
      <AppenderRef ref="Console"/>
    </Logger>
    
    <Root level="trace">
      <AppenderRef ref="Console"/>
    </Root>
  </Loggers>
</Configuration>
_______________________________________________________________________________________________________________________________________ 
  
3==saving the logs in the file.
  
  
  <?xml version="1.0" encoding="UTF-8"?>
<Configuration status="WARN">
 
<Properties>
<Property name="basePath">./logs</Property>
</Properties>
  
  
  <Appenders>
      <RollingFile name="File" fileName="${basePath}/prints.log" filePattern="${basePath}/prints-%d{yyyy-MM-dd}.log">
     <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
      <SizeBasedTriggeringPolicy size="500" />
          </RollingFile>
    <Console name="Console" target="SYSTEM_OUT">
      <PatternLayout pattern="%d{HH:mm:ss.SSS} [%t] %-5level %logger{36} - %msg%n"/>
    </Console>
  </Appenders>
  
  <Loggers>
  
  <Logger name="BLog4j.A" level="trace" additivity="false">
      <AppenderRef ref="File"/>
    </Logger>
    
    <Root level="trace">
      <AppenderRef ref="Console"/>
    </Root>
  </Loggers>
</Configuration>
  
  
  
  
  
  
  
  
 */
