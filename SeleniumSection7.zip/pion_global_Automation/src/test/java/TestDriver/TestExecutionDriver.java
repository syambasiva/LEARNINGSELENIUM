package TestDriver;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.test.pionglobal_Automation.testbase.Testbase;
import com.test.pionglobal_Automation.uiActions.CarrersPage;
import com.test.pionglobal_Automation.uiActions.LoginPage;
import com.test.pionglobal_Automation.uiActions.MainPage;

public class TestExecutionDriver extends Testbase {
	
	MainPage main;
	CarrersPage carrers;
	LoginPage login;
	
	
	@BeforeMethod
	public void setup() throws Exception
	{
		init();
	}
	
	
	@Test
	public void test02() throws InterruptedException{
		
		carrers = new CarrersPage();
		carrers.onclickcarrers();
		Thread.sleep(3000);
		carrers.onclickTechnology();
		carrers.Admin();
		
	}
	
	
	

	
}
