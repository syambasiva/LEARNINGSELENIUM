package com.test.pionglobal_Automation.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Testbase {
	
public static final Logger log = Logger.getLogger(Testbase.class.getName());


	
	
	public static  WebDriver driver;
	public Properties prop = new Properties();
	
	
	
	
	public void loadData () throws IOException {
		File file = new File(System.getProperty("user.dir") + "\\src\\main\\java\\com\\test\\pionglobal_Automation\\config\\config.properties");
	    FileInputStream fis = new FileInputStream(file);
	    prop.load(fis);
	}
	
	public void init() throws Exception {
		
		loadData();
		//String log4jConfPath = "log4j.properties";
		//PropertyConfigurator.configure(log4jConfPath);
		System.out.println(prop.getProperty("browser"));
		selectBrowser(prop.getProperty("browser"));
		getUrl(prop.getProperty("URL"));
		
		
	}
	
     public void selectBrowser (String browser) {
    	 System.out.println(System.getProperty("os.name"));
    	 if (System.getProperty("os.name").contains("Window")){
    		 if(browser.equals("chrome")) {
    			 System.out.println(System.getProperty("user.dir"));
    			 System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\drivers\\chromedriver.exe");
    			 ChromeOptions options = new ChromeOptions();
    			 options.addArguments("test-type");
    			 options.addArguments("disable-popup-blocking");
    			 DesiredCapabilities capabilities = DesiredCapabilities.chrome();
    			 driver = new ChromeDriver();
    			 /*
    			  * driver = new EventfiringWebDriver(dr);
    			  * eventListener = new WebEventListener();
    			  * driver.register(eventListener);
    			  * setDriver(driver);    	
    			  */
    		 } else if (browser.equals("firefox")) {
    			 System.out.println(System.getProperty("user.dir"));
    			 System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+ "");
    			 driver = new FirefoxDriver();
    		 }
    		 else if (System.getProperty("os.name").contains("Mac")){
        		 if(browser.equals("chrome")) {
        			 System.out.println(System.getProperty("user.dir"));
        			 System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+ "");
        			 driver = new ChromeDriver();
        			 
        		 }else if(browser.equals("firefox")) {
        			 System.out.println(System.getProperty("user.dir"));
        			 System.setProperty("webdriver.firefox.marionette",System.getProperty("user.dir")+ "");
        			 driver = new FirefoxDriver();
        	 }
    	 }
    	}
     }
	public void getUrl(String url) {
		
		log.info("navigating to :-" + url);
		driver.get(url);
		//driver.manage().window().maximize();
		//driver.manage().timeouts().implicityWait(10, TimeUnit.SECONDS);
	}
     
	
	public void waitForElement(WebDriver driver ,int timeOutInSeconds,WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	
	
	
}


