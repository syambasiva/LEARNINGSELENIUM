package com.test.pionglobal_Automation.uiActions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.pionglobal_Automation.testbase.Testbase;

public class MainPage extends Testbase{
	
	@FindBy(xpath="//a[text()='Login']")
	WebElement login; 
	
	public MainPage()
	{

		PageFactory.initElements(driver, this);
	}
	
	
	
	
public void clickonlogin()
{
	login.click();
}
	

}
