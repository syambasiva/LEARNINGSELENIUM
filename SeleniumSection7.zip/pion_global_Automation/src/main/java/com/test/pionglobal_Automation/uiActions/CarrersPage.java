package com.test.pionglobal_Automation.uiActions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.pionglobal_Automation.testbase.Testbase;

public class CarrersPage extends Testbase{
	
	@FindBy(xpath="//a[text()='Careers']")
	WebElement careers; 
     
	@FindBy(xpath="//h4[text()='Technology']")
	WebElement Technology; 
	
	@FindBy(xpath="//h6[text()='Admin']")
	WebElement Admin; 
	
	
	
	public CarrersPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void onclickcarrers()
	{
		careers.click();	
	}
	
	public void onclickTechnology()
	{
		Technology.click();	
	}
	
	public void Admin()
	{
		Admin.click();	
	}
}
