/*
 Relative- it does not depend on the parent nodes parent/child. directly traverse to the excat element.
 Absolute-it depends on parent and child 
 
 
 preffered Mostly:
 Relative is used because if developer changes the any div between entire xpath gets damaged.
 
 
 QAclickaccademy:
 
 RelativeXpath: //*[@id='tablist1-tab2']
 
 
 
 AbsoluteXpath://div[@class='responsive-tabs responsive-tabs--enabled']/ul/li[@id='tablist1-tab1']
 navigating from parent to child.
 
 from the top to reaching your desired element by navigating through nades in parent child formate is called Absolute Xpath.
 
 CONCEPT: NAVIGATING TO SiBLING
 /following-sibling::li[1]
 
 click on Appium,Selenium,SoapUI,Testing by using sibling relations
 
 CONCEPT:NAVIGATING FROM CHILD TO PARENT
 /parent::ul
  
  Interview Question:
  	The only difference is with X-path we can traverse back while with Css we cannot achieve
  
 */
package A;

public class CDifferenceBetweenRelativeAndAbsoluteXpath {
	

}
