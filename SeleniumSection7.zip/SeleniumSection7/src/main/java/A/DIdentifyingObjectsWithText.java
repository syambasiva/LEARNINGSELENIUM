//*[text()='']
package A;

public class DIdentifyingObjectsWithText {
	
	
	public static void main(String[] args) {
		
	}

}
