package A;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AHowToHandleTableGrids {
	
	public static void main(String[] args) {
		
	int sum =0;
	System.setProperty("webdriver.chrome.driver","C:\\Users\\syambasiva.kuraba\\Documents\\NewSeleniumDriver\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
    driver.get("https://www.cricbuzz.com/live-cricket-scorecard/23269/indw-vs-rsaw-1st-t20i-south-africa-women-tour-of-india-2019");

    
    WebElement table = driver.findElement(By.xpath("//div[@id='innings_1']/div[1]"));
	
   
   int rowCount = table.findElements(By.xpath("//div[@id='innings_1']/div[1]//div[@class='cb-col cb-col-100 cb-scrd-itms']")).size();
    
   int Count = table.findElements(By.xpath("//div[@id='innings_1']/div[1]/div[@class='cb-col cb-col-100 cb-scrd-itms']//div[@class='cb-col cb-col-8 text-right text-bold']")).size();
   
   for(int i=0;i<Count;i++)
   {
	   String value = table.findElements(By.xpath("//div[@id='innings_1']/div[1]/div[@class='cb-col cb-col-100 cb-scrd-itms']//div[@class='cb-col cb-col-8 text-right text-bold']")).get(i).getText();
      
	   int valueInteger = Integer.parseInt(value);//Converting String into Integer
	   sum = sum+valueInteger;
	   }
   
     
   String Extras = driver.findElement(By.xpath("//div[@id='innings_1']//div[text()='Extras']/following-sibling::div[1]")).getText();
   int extraValues = Integer.parseInt(Extras);
   int TotalSumValue = sum+extraValues;
   System.out.println(TotalSumValue);
   
   
   String ActualTotal = driver.findElement(By.xpath("//div[@id='innings_1']//div[text()='Total']/following-sibling::div[1]")).getText();
	int ActualTotalValue = Integer.parseInt(ActualTotal);
	
	if(ActualTotalValue==TotalSumValue) 
	{
       System.out.println("Count Matches");		
	}
	else
	{
		System.out.println("Count Fail");
	}
   
	}	   	
   		
   	

}
