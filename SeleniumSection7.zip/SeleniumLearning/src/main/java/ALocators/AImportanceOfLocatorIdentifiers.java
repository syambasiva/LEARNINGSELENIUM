/*
1.ID
2.className
3.Name
4.linktext
5.xpath
6.Css


All elements will not have ID that depends on developers so Xpath and Css is common all over the world 
so we can go with xpath and Css if id is not present
*******************************************************************************
1.ALPHANUMERIC ID MAY CHANGES EVERY TIME WHEN THE BROWSER REFRESHES.

2.CCOFIRM THE  LINK WHEN WE SEE "ANCHOR TAG"

3.CLASSES SHOULD NOT HAVE SPACES -CAMPOUND CLASSES CANNOT BE ACCEPTED 

4.multiple values i.e ids or name or class selenium identifies first one from top left).

5.doublecodes inside doublecodes are not accepted.

6..Xpaths can be defined in n number of ways.

7..RightClick copy on blue highlighted to generate Xpath

8.firepath 

9.when Xpath starts with HTML-not-reliable switch browser to get other one

10.There is no direct way to get css in chrome.you will find it in tool bar

11.$("")-for CSS  $x("")-for xpath

12. //tagName[@attribute='value'] <---> xpath

13. tagName[attribute='value']  <--->CSS  , tagname#id , tagname.classname ,   #id

14.RegularExpressionConcept:when the attribute value is changing every time when the browser refreshes how to write Xpath?

//tagname[contains(@attribute,'value')] --> xpath

tagname[attribute*='value']





*******************************************************************************


ID AND NAME:

1.Every object may not have ID,CLASSNAME,NAME,LINKTEST,XPATH,CSS.(multiple ids or name or class selenium identifies first one from
top left).
2.ALPHANUMERIC ID MAY CHANGES EVERY TIME WHEN THE BROWSER REFRESHES.
-->(Xpaths for facebooklogin page)


LINKTEXT:

3.CCOFIRM THE  LINK WHEN WE SEE "ANCHOR TAG"

CLASSNAME:

4.CLASSES SHOULD NOT HAVE SPACES -CAMPOUND CLASSES CANNOT BE ACCEPTED 
-->(salesforce)

XPATHS AND CSS:(how to get Xpath and Css From browser tools)

1.doublecodes inside doublecodes are not accepted.
2.Xpaths can be defined in n number of ways.
3.RightClick copy on blue highlighted to generate Xpath

HOW TO VALIDATE XPATH AND CSS FROM BROWSER ADONS:

verifying or validating {for xpath by using console $x(""); and for CSS $("") }
                                              
 */

package ALocators;

public class AImportanceOfLocatorIdentifiers {

}
