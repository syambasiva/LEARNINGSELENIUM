//facebook and salesfoece and rediff 
package ALocators;

public class BPracticeAllAboveConcepts {

}
