/*
 //tagName[@attribute='value'] <---> xpath
  
  By using regular Expression:
   //*[@attribute='value']
 
 //tagName[attribute='value']  <--->CSS
  tagname#id
  tagname.classname
  #id
  
  
  
  */
   
 
package ALocators;

public class CGeneratingCustomisedXpathfromHtmlAttributes {
	

}
