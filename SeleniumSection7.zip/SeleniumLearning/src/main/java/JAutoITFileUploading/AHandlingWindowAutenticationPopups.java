package JAutoITFileUploading;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AHandlingWindowAutenticationPopups {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ "\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		/*
		   http://Username:Password@SiteURL
		 */
		//https://the-internet.herokuapp.com
		driver.get("http://admin:admin@the-internet.herokuapp.com");
		driver.findElement(By.xpath("//a[text()='Basic Auth']")).click();
	}
}
