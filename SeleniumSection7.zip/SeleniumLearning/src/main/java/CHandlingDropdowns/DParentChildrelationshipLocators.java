package CHandlingDropdowns;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DParentChildrelationshipLocators {

	
	public static void main(String[] args) throws InterruptedException {
		
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ "\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.spicejet.com");
		
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		
		driver.findElement(By.xpath("//a[@value='BLR']")).click();
		Thread.sleep(2000);
		
		/*
		 * driver.findElement(By.xpath("//a[@value='MAA']")).click();  
		  error: for dynamic if index is not specified
		 MSG: element not interactable by default it will search for the index 1 when the dropdown load for first time.
		 
		driver.findElement(By.xpath("//a[@value='MAA'](2)")).click();
		error:for wrong xpath
		MSG:Unable to locate an element with the xpath expression //a[@value='MAA'](2)
			*/
		
		
		//driver.findElement(By.xpath("(//a[@value='MAA'])[2]")).click();
		

		driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value='MAA']")).click();
		
		
	}
}
