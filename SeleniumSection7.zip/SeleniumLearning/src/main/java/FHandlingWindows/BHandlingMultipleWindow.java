/*
 window ids will be in the form of string and store in "set Data Structure"
 
 by using the Iterator method 	we can iterator to multiple steps in datastructure.
 
 
 */
package FHandlingWindows;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BHandlingMultipleWindow {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ "\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://accounts.google.com/signup");
		driver.findElement(By.linkText("Help")).click();
		System.out.println(driver.getTitle());
		
		  Set<String> ids =driver.getWindowHandles();
        
		  Iterator<String> it = ids.iterator();
		  
		  String ParendId = it.next();
		  String childId = it.next();
		  
		  driver.switchTo().window(childId);
		  
		  System.out.println(driver.getTitle());
		
	

	}
}
