/*
 Drawback of Selenium: 
 javaScript DOM can Extract the hidden Elements
 hidden elements cannot be identified. or any Ajax Implementations
 investigate the properties of objects if it have any hidden Text.
 */
package HhandlingTableGridsAndAutosuggestiveDropdowns;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BHandlingAutoSuggestiveDropdowns {
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ "\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://ksrtc.in");
		
		driver.findElement(By.xpath("//input[@id='fromPlaceName']")).sendKeys("BENG");
		Thread.sleep(5000);
		
	    //driver.findElement(By.xpath("//input[@id='fromPlaceName']")).sendKeys(Keys.DOWN);
		//System.out.println(driver.findElement(By.xpath("//input[@id='fromPlaceName']")).getText());
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		String Script = "return document.getElementById(\"fromPlaceName\").value;";
		String text =(String) js.executeScript(Script);
	   	System.out.println(text);
	   	
	   
	   	int i=0;
	   	
	   	while(!text.equalsIgnoreCase("BENGALURU INTERNATION AIRPORT"))
	   	{
	   		i++;
	   	   driver.findElement(By.xpath("//input[@id='fromPlaceName']")).sendKeys(Keys.DOWN);
	   		text =(String) js.executeScript(Script);
		    System.out.println(text);
		   	if(i>10)
		   	{
		   		break;
		   	}
	   	}
		   	if(i>10)
		   	{
		   		System.out.println("Element Not Found");
		   	}
		   	else
		   	{
		   		System.out.println("Element found");
		   	}
	   		
	   	}
	
		
	}


