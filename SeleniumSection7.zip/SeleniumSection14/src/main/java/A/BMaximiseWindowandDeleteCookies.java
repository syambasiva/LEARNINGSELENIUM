package A;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BMaximiseWindowandDeleteCookies {
	
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window();
		driver.manage().deleteAllCookies();
		//driver.manage().deleteCookieNamed("SessionKey");
		
		//click on any link it will redirected to homePage verify URL
		
		driver.get("https://www.google.co.in");
		
	}

}
