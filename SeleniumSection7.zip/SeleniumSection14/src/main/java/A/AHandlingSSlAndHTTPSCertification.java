/*Handling insecure and SSLC certifications
 
 by using chromeOptions we can do it.
 
 we merge desiredCapabilities to chromeOptions
 
 DesiredCapabilities is a class which help to custamise chrome browser.
 
 */
package A;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class AHandlingSSlAndHTTPSCertification {
	
	public static void main(String[] args) {
		
		
		
	/*
	 Https and ssl certifications can be handled by desired Capabilities and chromeOptions class
	 */
	DesiredCapabilities ch = DesiredCapabilities.chrome(); //creating general chrome browser
	ch.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
	ch.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		
	
	ChromeOptions c = new ChromeOptions();//local chrome browser chrome options is used to set your local chrome browser settings
	c.merge(ch);//giving knowledge to local browser about the general browser so now it can handle 
	
	System.setProperty("", "");
	WebDriver driver = new ChromeDriver(c);
	}
}



