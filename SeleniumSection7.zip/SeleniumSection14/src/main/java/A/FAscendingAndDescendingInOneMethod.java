package A;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class FAscendingAndDescendingInOneMethod {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\syambasiva.kuraba\\Documents\\Selenium drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");

		// first remove the below two steps and run and check and then add
		driver.findElement(By.cssSelector("tr th:nth-child(2)")).click();
		driver.findElement(By.cssSelector("tr th:nth-child(2)")).click();

		List<WebElement> firstColList = driver.findElements(By.cssSelector("tr td:nth-child(2)"));
		// sortColumn(firstColList,"desc");
		sortColumn(firstColList, "de");
	}

	public static void sortColumn(List<WebElement> firstColList, String order) {
		ArrayList<String> OrginalList = new ArrayList<String>();
		for (int i = 0; i < firstColList.size(); i++) {

			OrginalList.add(firstColList.get(i).getText());
		}

		ArrayList<String> CopiedList = new ArrayList<String>();
		for (int i = 0; i < OrginalList.size(); i++) {
			CopiedList.add(OrginalList.get(i));
		}

		System.out.println("****************************************************************************************");
		Collections.sort(CopiedList);
		if (order.equalsIgnoreCase("desc")) {
			Collections.reverse(CopiedList);
		}
		for (String s : CopiedList) {
			System.out.println(s);
		}
		System.out.println("*****************************************************************************************");
		for (String s : OrginalList) {
			System.out.println(s);
		}

		Assert.assertTrue(OrginalList.equals(CopiedList));
	}

}
